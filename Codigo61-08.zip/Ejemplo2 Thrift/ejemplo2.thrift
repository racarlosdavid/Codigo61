namespace java ejemplo2
namespace cpp ejemplo2

service Ejemplo2{
	void insertar(1:i32 llave, 2:i32 edad, 3:string nombre, 4:string apellido),
	void graficar()
}