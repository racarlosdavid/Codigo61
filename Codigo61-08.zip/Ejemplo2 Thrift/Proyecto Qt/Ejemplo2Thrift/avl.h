#ifndef AVL_H
#define AVL_H


class avl
{
public:
    avl();
    /*
    typedef struct Datos{
        int x,y,z,vida,alcance,ataque,alcanceataque;
        char *nivel;
        char *tipo;
    }Datos;
    */

    typedef struct avlnode
    {
        int clave;
        int edad;
        char *nombre;
        char *apellido;
        //Datos *datos;
        int bal; /* Factor de balance -1,0,1 */
        struct avlnode *left, *right;
    } nodo, *pnodo;





    //los metodos
    static pnodo lrot(pnodo t);
    static pnodo rrot(pnodo t);
    static void Error(int tipo);
    int Altura(void);
    pnodo CreaNodo(int key);
    pnodo insertR(pnodo t);
    pnodo InsertarAVL(int clave,int edad,char *nombre,char *apellido,pnodo t);
    pnodo deleteR(pnodo t);
    pnodo DescartarAVL(int clave, pnodo t);
    pnodo deltreeR(pnodo t);
    pnodo deltree(pnodo t);
    void InOrder(pnodo raiz);
    void g(pnodo raiz);
    void inorder(pnodo t, int profundidad);
};

#endif // AVL_H
