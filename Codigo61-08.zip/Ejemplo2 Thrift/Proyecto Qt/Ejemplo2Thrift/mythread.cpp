#include "mythread.h"
#include <QDebug>
#include <QtCore>
//#include "avl.h"
//#include <avl.h>
/*
#include "P1.h"
#include <thrift/protocol/TBinaryProtocol.h>
#include <thrift/server/TSimpleServer.h>
#include <thrift/transport/TServerSocket.h>
#include <thrift/transport/TBufferTransports.h>

using namespace ::apache::thrift;
using namespace ::apache::thrift::protocol;
using namespace ::apache::thrift::transport;
using namespace ::apache::thrift::server;

using boost::shared_ptr;

using namespace  ::EDDP1;

class P1Handler : virtual public P1If {
 public:
  P1Handler() {
    // Your initialization goes here
  }

  void ObtenerValor(std::string& _return, const int32_t num1, const int32_t num2) {
    // Your implementation goes here
    printf("ObtenerValor\n");
  }

  int32_t EliminarNodoJ1(const int32_t clave) {
    // Your implementation goes here
    printf("EliminarNodoJ1\n");
  }

  int32_t EliminarNodoJ2(const int32_t clave) {
    // Your implementation goes here
    printf("EliminarNodoJ2\n");
  }

};
*/

MyThread::MyThread(QObject *parent, bool b) :
    QThread(parent), Stop(b)
{
}

// run() will be called when a thread starts
/*
void MyThread::run()
{
    while (!Stop) {
        int port = 9090;
          shared_ptr<P1Handler> handler(new P1Handler());
          shared_ptr<TProcessor> processor(new P1Processor(handler));
          shared_ptr<TServerTransport> serverTransport(new TServerSocket(port));
          shared_ptr<TTransportFactory> transportFactory(new TBufferedTransportFactory());
          shared_ptr<TProtocolFactory> protocolFactory(new TBinaryProtocolFactory());

          TSimpleServer server(processor, serverTransport, transportFactory, protocolFactory);
          server.serve();

    }


}
*/
