#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "avl.h"
#include "mythread.h"

avl::pnodo usuarios;
avl arbol;

#include "Ejemplo2.h"
#include <thrift/protocol/TBinaryProtocol.h>
#include <thrift/server/TSimpleServer.h>
#include <thrift/transport/TServerSocket.h>
#include <thrift/transport/TBufferTransports.h>


// metodos de thrift
using namespace ::apache::thrift;
using namespace ::apache::thrift::protocol;
using namespace ::apache::thrift::transport;
using namespace ::apache::thrift::server;

using boost::shared_ptr;

using namespace  ::ejemplo2;

class Ejemplo2Handler : virtual public Ejemplo2If {
 public:
  Ejemplo2Handler() {
    // Your initialization goes here
  }

  void insertar(const int32_t llave, const int32_t edad, const std::string& nombre, const std::string& apellido) {
    char *nom = new char[nombre.size()+1];
    char *ap = new char[apellido.size()+1];
    strcpy(nom,nombre.c_str());
    strcpy(ap,apellido.c_str());
    usuarios=arbol.InsertarAVL(llave,edad,nom,ap,usuarios);
    printf("insertar\n");
  }

  void graficar() {
    arbol.g(usuarios);
    printf("graficar\n");
  }

};

void MyThread::run(){
    while (!Stop) {
        int port = 9090;
          shared_ptr<Ejemplo2Handler> handler(new Ejemplo2Handler());
          shared_ptr<TProcessor> processor(new Ejemplo2Processor(handler));
          shared_ptr<TServerTransport> serverTransport(new TServerSocket(port));
          shared_ptr<TTransportFactory> transportFactory(new TBufferedTransportFactory());
          shared_ptr<TProtocolFactory> protocolFactory(new TBinaryProtocolFactory());

          TSimpleServer server(processor, serverTransport, transportFactory, protocolFactory);
          server.serve();
    }
}

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    mThread = new MyThread(this);

    connect(mThread,SIGNAL(valueChanged(int)),this,SLOT(onValueChanged(int)));

    mThread->start();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::onValueChanged(int v){

}
