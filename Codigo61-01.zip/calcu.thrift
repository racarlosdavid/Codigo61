namespace java calcu
namespace cpp calcu

service Calculadora{
	i32 sumar(1:i32 num1, 2:i32 num2),
	i32 multiplicar(1:i32 num1, 2:i32 num2)
}