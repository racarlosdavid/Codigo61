#include <QCoreApplication>
#include <iostream>
#include <stdlib.h>
#include "Calculadora.h"
#include <thrift/protocol/TBinaryProtocol.h>
#include <thrift/server/TSimpleServer.h>
#include <thrift/transport/TServerSocket.h>
#include <thrift/transport/TBufferTransports.h>

using namespace ::apache::thrift;
using namespace ::apache::thrift::protocol;
using namespace ::apache::thrift::transport;
using namespace ::apache::thrift::server;

using boost::shared_ptr;

using namespace  ::calcu;

class CalculadoraHandler : virtual public CalculadoraIf {
 public:
  CalculadoraHandler() {
    // Your initialization goes here
  }

  int32_t sumar(const int32_t num1, const int32_t num2) {
    std::cout << "Sumar "<< num1<< " + " <<num2 << std::endl;
    return num1+num2;
  }

  int32_t multiplicar(const int32_t num1, const int32_t num2) {
      std::cout << "Multiplicar "<< num1<< " * " <<num2 << std::endl;
      return num1*num2;
  }

};

int main(int argc, char **argv) {
  int port = 9090;
  shared_ptr<CalculadoraHandler> handler(new CalculadoraHandler());
  shared_ptr<TProcessor> processor(new CalculadoraProcessor(handler));
  shared_ptr<TServerTransport> serverTransport(new TServerSocket(port));
  shared_ptr<TTransportFactory> transportFactory(new TBufferedTransportFactory());
  shared_ptr<TProtocolFactory> protocolFactory(new TBinaryProtocolFactory());

  TSimpleServer server(processor, serverTransport, transportFactory, protocolFactory);
  server.serve();
  return 0;
}

