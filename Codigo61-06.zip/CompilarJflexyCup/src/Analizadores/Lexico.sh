java -jar /Users/CarlosDavid/Desktop/Fuente/jflex-1.6.1.jar A_Lexico.jflex
